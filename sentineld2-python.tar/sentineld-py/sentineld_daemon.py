#!/usr/bin/env python3
"""
sentineld - local, transparent, user-decides process monitor.

Every decision about what's suspicious is made on this machine. Nothing
is uploaded anywhere. When something looks suspicious, this freezes it
and asks you -- it never kills silently.

This is the Python rewrite of the original C/assembly prototype. The
core security properties are unchanged (local-only heuristics, human
confirmation before any kill, content-hash blocklist, Bayesian learning
from real decisions with a reflex-click guard, freeze-timeout fail-safe),
but the implementation trades hand-rolled syscall stubs and manual struct
packing for Python's standard library -- fewer places for a subtle byte-
layout bug to hide silently, at the cost of a much larger trusted base
(the Python interpreter itself) than the original's ~20KB static binary.
See README.md for the honest tradeoff discussion.
"""
import grp
import json
import os
import selectors
import socket
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sentineld.bayes import BayesModel, EXPLANATIONS
from sentineld.features import extract_features, resolve_exe_path, parse_status
from sentineld.process_control import (
    fingerprint_process, get_process_start_time, stop_and_confirm,
    resume_process, kill_and_confirm, Blocklist,
)
from sentineld.netlink import NetlinkProcConnector, PROC_EVENT_EXEC, PROC_EVENT_PTRACE
from sentineld.bt_bayes import BTBayesModel, EXPLANATIONS as BT_EXPLANATIONS
from sentineld.bluetooth import BluetoothMonitor

STATE_DIR = "/var/lib/sentineld"
MODEL_PATH = os.path.join(STATE_DIR, "model.json")
BLOCKLIST_PATH = os.path.join(STATE_DIR, "blocklist.json")
BT_MODEL_PATH = os.path.join(STATE_DIR, "bt_model.json")
SOCK_PATH = "/run/sentineld.sock"
SOCK_GROUP = "sentineld"

ALERT_THRESHOLD = 0.55
FREEZE_TIMEOUT_SECS = 120
MIN_DECISION_SECS = 2

BT_ALERT_THRESHOLD = 0.55
# A BT alert for the same address won't fire again until this much time
# has passed, even if new features fire -- otherwise a device sitting at
# a borderline score can re-alert on every RSSI wobble.
BT_REALERT_COOLDOWN_SECS = 60
# Unlike process alerts, nothing is frozen while a BT alert is pending --
# there's nothing to hold hostage. This just bounds how long an unanswered
# alert stays eligible for training if a late decision arrives.
BT_PENDING_TIMEOUT_SECS = 300

KNOWN_DEBUGGERS = {"gdb", "strace", "ltrace", "valgrind", "perf", "lldb", "rr"}


def log(msg):
    print(f"sentineld: {msg}", flush=True)


class PendingAlert:
    def __init__(self, alert_id, pid, start_time, features):
        self.alert_id = alert_id
        self.pid = pid
        self.start_time = start_time
        self.features = features
        self.created_at = time.monotonic()


class PendingBTAlert:
    """Bluetooth alerts have no process to freeze or kill -- there's
    nothing to pause while the user decides, and nothing to time out and
    auto-resume. This just tracks enough to apply the user's decision
    (train the model) when it arrives, and to enforce the re-alert
    cooldown per address."""
    def __init__(self, alert_id, address, features):
        self.alert_id = alert_id
        self.address = address
        self.features = features
        self.created_at = time.monotonic()


class Daemon:
    def __init__(self):
        self.model = BayesModel.load(MODEL_PATH)
        self.blocklist = Blocklist.load(BLOCKLIST_PATH)
        self.pending = {}
        self.next_alert_id = 1
        self.clients = []
        self.sel = selectors.DefaultSelector()
        self.netlink = NetlinkProcConnector(log=log)
        self.listen_sock = None

        self.bt_model = BTBayesModel.load(BT_MODEL_PATH)
        self.bluetooth = BluetoothMonitor(log=log)
        self.bt_pending = {}
        self.next_bt_alert_id = 1
        self.bt_last_alert_at = {}  # address -> monotonic time of last alert

    def setup(self):
        os.makedirs(STATE_DIR, exist_ok=True)

        self.netlink.open()
        self.sel.register(self.netlink.sock, selectors.EVENT_READ, self._on_netlink)

        try:
            self.bluetooth.open()
            self.sel.register(self.bluetooth.proc.stdout, selectors.EVENT_READ, self._on_bluetooth)
        except (OSError, FileNotFoundError) as e:
            log(f"WARNING: bluetooth monitoring disabled, could not start bluetoothctl: {e}")

        if os.path.exists(SOCK_PATH):
            os.unlink(SOCK_PATH)
        self.listen_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.listen_sock.bind(SOCK_PATH)
        os.chmod(SOCK_PATH, 0o660)
        try:
            gid = grp.getgrnam(SOCK_GROUP).gr_gid
            os.chown(SOCK_PATH, -1, gid)
        except KeyError:
            log(f"WARNING: group '{SOCK_GROUP}' does not exist -- socket left "
                f"owned by root only. Run: sudo groupadd {SOCK_GROUP}")
        self.listen_sock.listen(8)
        self.sel.register(self.listen_sock, selectors.EVENT_READ, self._on_accept)

        log("running (local heuristics only, no cloud calls)")

    def _on_accept(self, sock):
        conn, _ = sock.accept()
        conn.setblocking(False)
        self.clients.append(conn)
        self.sel.register(conn, selectors.EVENT_READ, self._on_client_data)
        log(f"client connected (now {len(self.clients)} client(s) connected)")

    def _drop_client(self, conn):
        try:
            self.sel.unregister(conn)
        except KeyError:
            pass
        if conn in self.clients:
            self.clients.remove(conn)
        conn.close()
        log(f"client disconnected (now {len(self.clients)} client(s) connected)")

    def _on_client_data(self, conn):
        try:
            data = conn.recv(4096)
        except OSError:
            self._drop_client(conn)
            return
        if not data:
            self._drop_client(conn)
            return
        for line in data.decode("utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                decision = json.loads(line)
                self._handle_decision(decision)
            except json.JSONDecodeError:
                log(f"WARNING: malformed decision from client, ignored: {line!r}")

    def _broadcast(self, obj):
        payload = (json.dumps(obj) + "\n").encode("utf-8")
        log(f"broadcasting alert to {len(self.clients)} connected client(s)")
        for conn in list(self.clients):
            try:
                conn.sendall(payload)
            except OSError as e:
                log(f"send to client failed ({e}), dropping it")
                self._drop_client(conn)

    def _on_netlink(self, sock):
        for what, payload in self.netlink.read_events():
            if what == PROC_EVENT_EXEC and len(payload) >= 4:
                pid = int.from_bytes(payload[0:4], sys.byteorder)
                self._handle_exec(pid)
            elif what == PROC_EVENT_PTRACE and len(payload) >= 16:
                tracee_pid = int.from_bytes(payload[0:4], sys.byteorder)
                tracer_pid = int.from_bytes(payload[8:12], sys.byteorder)
                self._handle_ptrace(tracer_pid, tracee_pid)

    def _on_bluetooth(self, _stream):
        for device, fired in self.bluetooth.read_events():
            score = self.bt_model.score(fired)
            log(f"bluetooth: scored '{device.alias or device.address}' at {score*100:.0f}% "
                f"(threshold {BT_ALERT_THRESHOLD*100:.0f}%), features={sorted(fired)}")

            if score < BT_ALERT_THRESHOLD:
                continue

            last = self.bt_last_alert_at.get(device.address, 0.0)
            if time.monotonic() - last < BT_REALERT_COOLDOWN_SECS:
                continue
            self.bt_last_alert_at[device.address] = time.monotonic()

            alert_id = self.next_bt_alert_id
            self.next_bt_alert_id += 1
            self.bt_pending[alert_id] = PendingBTAlert(alert_id, device.address, fired)

            self._broadcast({
                "type": "bt_alert",
                "alert_id": alert_id,
                "address": device.address,
                "alias": device.alias,
                "connected": device.connected,
                "rssi": device.rssi_history[-1][1] if device.rssi_history else None,
                "score": score,
                "features": sorted(fired),
                "explanations": [BT_EXPLANATIONS.get(f, f) for f in sorted(fired)],
            })

    def _score_and_maybe_alert(self, pid, exe_path, comm, ppid, parent_comm,
                                context_note="", extra_features=None):
        fired = extract_features(pid, exe_path, comm, ppid, parent_comm)
        if extra_features:
            fired |= extra_features
        score = self.model.score(fired)
        log(f"scored '{comm}' ({exe_path}) at {score*100:.0f}% "
            f"(threshold {ALERT_THRESHOLD*100:.0f}%), features={sorted(fired)}")

        if score < ALERT_THRESHOLD:
            return

        stop_and_confirm(pid)
        start_time = get_process_start_time(pid)
        alert_id = self.next_alert_id
        self.next_alert_id += 1
        self.pending[alert_id] = PendingAlert(alert_id, pid, start_time, fired)

        self._broadcast({
            "type": "alert",
            "alert_id": alert_id,
            "pid": pid,
            "exe_path": exe_path,
            "comm": comm,
            "ppid": ppid,
            "parent_comm": parent_comm,
            "score": score,
            "features": sorted(fired),
            "explanations": [EXPLANATIONS.get(f, f) for f in sorted(fired)],
            "context_note": context_note,
        })

    def _handle_exec(self, pid):
        log(f"exec event received for pid {pid}")
        exe_path, digest = fingerprint_process(pid)
        if exe_path is None:
            log(f"could not fingerprint pid {pid} (likely already exited)")
            return

        if self.blocklist.contains(digest):
            stop_and_confirm(pid)
            start_time = get_process_start_time(pid)
            kill_and_confirm(pid, start_time)
            log(f"re-exec of blocked binary killed automatically (pid {pid})")
            return

        comm, ppid = parse_status(pid)
        comm = comm or "?"
        parent_comm = "?"
        if ppid:
            parent_comm, _ = parse_status(ppid)
            parent_comm = parent_comm or "?"

        self._score_and_maybe_alert(pid, exe_path, comm, ppid, parent_comm)

    def _handle_ptrace(self, tracer_pid, tracee_pid):
        if tracer_pid <= 0 or tracee_pid <= 0 or tracer_pid == tracee_pid:
            return
        tracer_comm, _ = parse_status(tracer_pid)
        if tracer_comm in KNOWN_DEBUGGERS:
            return  # routine developer activity, don't interrupt

        exe_path, digest = fingerprint_process(tracer_pid)
        if exe_path is None:
            return

        if self.blocklist.contains(digest):
            stop_and_confirm(tracer_pid)
            start_time = get_process_start_time(tracer_pid)
            kill_and_confirm(tracer_pid, start_time)
            log(f"blocked binary attempted ptrace injection, killed automatically (pid {tracer_pid})")
            return

        tracee_comm, _ = parse_status(tracee_pid)
        note = (f"This is attaching to already-running process "
                f"'{tracee_comm or '?'}' (pid {tracee_pid}), not launching something new.")
        self._score_and_maybe_alert(tracer_pid, exe_path, tracer_comm or "?", 0, "",
                                     context_note=note,
                                     extra_features={"ptrace_injection"})

    def _handle_decision(self, decision):
        if decision.get("type") == "bt_decision":
            self._handle_bt_decision(decision)
            return

        alert_id = decision.get("alert_id")
        kind = decision.get("kind")
        pa = self.pending.pop(alert_id, None)
        if pa is None:
            return

        elapsed = time.monotonic() - pa.created_at
        trainable = elapsed >= MIN_DECISION_SECS
        if not trainable:
            log("decision arrived unusually fast; applying it but not training the model")

        if kind == "block":
            exe_path, digest = fingerprint_process(pa.pid)
            kill_and_confirm(pa.pid, pa.start_time)
            if digest:
                self.blocklist.add(digest, exe_path or "?")
                self.blocklist.save(BLOCKLIST_PATH)
            if trainable:
                self.model.update(pa.features, True)
                self.model.save(MODEL_PATH)
            log(f"user blocked pid {pa.pid}; killed and remembered")
        elif kind == "false_positive":
            resume_process(pa.pid)
            if trainable:
                self.model.update(pa.features, False)
                self.model.save(MODEL_PATH)
            log(f"user marked pid {pa.pid} as false positive; learned as benign")
        else:  # allow
            resume_process(pa.pid)
            log(f"user allowed pid {pa.pid} to continue (untrained)")

    def _handle_bt_decision(self, decision):
        """BT decisions never freeze/kill anything -- there's no process
        behind a Bluetooth address. 'trust' and 'false_positive' both
        train the model as benign (kept as separate decision kinds for
        symmetry with the process protocol and because a future version
        may want to also add the address to a local allow-list on
        'trust' specifically). 'flag' trains as malicious so a
        confirmed-suspicious device keeps getting flagged, and its score
        can only go up from repeated genuine confirmations, not from a
        single reflex click. 'dismiss' applies no training at all."""
        alert_id = decision.get("alert_id")
        kind = decision.get("kind")
        pa = self.bt_pending.pop(alert_id, None)
        if pa is None:
            return

        elapsed = time.monotonic() - pa.created_at
        trainable = elapsed >= MIN_DECISION_SECS
        if not trainable:
            log("bluetooth: decision arrived unusually fast; not training the model")

        if kind == "flag":
            if trainable:
                self.bt_model.update(pa.features, True)
                self.bt_model.save(BT_MODEL_PATH)
            log(f"user flagged bluetooth device {pa.address} as suspicious; remembered")
        elif kind in ("trust", "false_positive"):
            if trainable:
                self.bt_model.update(pa.features, False)
                self.bt_model.save(BT_MODEL_PATH)
            log(f"user marked bluetooth device {pa.address} as trusted/benign; learned")
        else:  # dismiss
            log(f"user dismissed bluetooth alert for {pa.address} (untrained)")

    def _sweep_expired(self):
        now = time.monotonic()
        expired = [aid for aid, pa in self.pending.items()
                   if now - pa.created_at >= FREEZE_TIMEOUT_SECS]
        for aid in expired:
            pa = self.pending.pop(aid)
            resume_process(pa.pid)
            log(f"alert {aid} unanswered, auto-resumed pid {pa.pid} (not trained, not blocked)")

        expired_bt = [aid for aid, pa in self.bt_pending.items()
                      if now - pa.created_at >= BT_PENDING_TIMEOUT_SECS]
        for aid in expired_bt:
            pa = self.bt_pending.pop(aid)
            log(f"bluetooth alert {aid} for {pa.address} unanswered, dropped (not trained)")

    def run(self):
        self.setup()
        try:
            while True:
                events = self.sel.select(timeout=5)
                for key, _mask in events:
                    callback = key.data
                    callback(key.fileobj)
                self._sweep_expired()
        finally:
            self.bluetooth.close()


def main():
    if os.geteuid() != 0:
        print("sentineld must run as root (needs CAP_NET_ADMIN, CAP_KILL, etc.)", file=sys.stderr)
        sys.exit(1)
    Daemon().run()


if __name__ == "__main__":
    main()
