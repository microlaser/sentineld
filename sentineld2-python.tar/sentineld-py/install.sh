#!/bin/bash
set -e

if [ "$EUID" -ne 0 ]; then
    echo "run as root: sudo ./install.sh"
    exit 1
fi

echo "Installing sentineld (Python)..."

getent group sentineld >/dev/null || groupadd sentineld
install -d -g sentineld -m 0750 /var/lib/sentineld
install -d /usr/local/lib/sentineld

cp -r sentineld /usr/local/lib/sentineld/
cp sentineld_daemon.py /usr/local/lib/sentineld/
chmod -R go+rX /usr/local/lib/sentineld

install -m 0755 sentinelctl.py /usr/local/bin/sentinelctl
install -m 0644 sentineld.service /etc/systemd/system/sentineld.service

systemctl daemon-reload

echo ""
echo "Installed. Add your user to the sentineld group, then log out/in:"
echo "  sudo usermod -aG sentineld \$USER"
echo ""
echo "Then start it:"
echo "  sudo systemctl enable --now sentineld"
echo "  journalctl -u sentineld -f"
echo ""
echo "And in another terminal (after logging back in):"
echo "  sentinelctl"
