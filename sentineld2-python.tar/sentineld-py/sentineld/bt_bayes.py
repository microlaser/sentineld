"""
Naive Bayes classifier for Bluetooth anomaly scoring. Structurally
identical to bayes.py (informed prior, only-fired-features count as
evidence, atomic JSON persistence) -- see that file's docstring for the
reasoning shared here.

Kept as a separate model and a separate JSON file (bt_model.json) rather
than folding into the process model, because the two feature spaces
measure completely different things (exec-time filesystem/privilege
signals vs. RF proximity/identity/timing signals) and mixing their
counts would let training data from one domain quietly bias the other's
scores.
"""
import json
import os

FEATURES = [
    "new_unpaired_device",
    "alias_mac_mismatch",
    "rssi_jump_close",
    "rapid_connect_cycle",
    "unnamed_persistent",
    "uuid_set_changed",
    "manufacturer_id_unlisted",
    "advertisement_burst",
]

EXPLANATIONS = {
    "new_unpaired_device": "This is a device sentineld has never seen before, and it isn't paired or trusted.",
    "alias_mac_mismatch": "It's broadcasting the same name as a device you already trust, but from a different address -- that's what a spoofed or cloned device looks like.",
    "rssi_jump_close": "Its signal just got much stronger, meaning whatever this is moved a lot closer, very recently.",
    "rapid_connect_cycle": "It has connected and disconnected several times in under a minute, which isn't how ordinary accessories behave.",
    "unnamed_persistent": "It's broadcasting with no name at all, and it keeps showing up rather than passing through once.",
    "uuid_set_changed": "The services it's advertising changed since sentineld last recorded this device -- possibly a different device reusing the same address.",
    "manufacturer_id_unlisted": "Its manufacturer data doesn't match any of the common, well-known vendor IDs.",
    "advertisement_burst": "A number of brand-new devices all appeared within a few seconds of each other, which can indicate active scanning or a spoofing tool nearby rather than normal foot traffic.",
}


class BTBayesModel:
    def __init__(self):
        self.malicious_total = 4
        self.benign_total = 20
        self.feature_mal = {f: 3 for f in FEATURES}
        self.feature_ben = {f: 0 for f in FEATURES}
        # Two features are weak signals on their own -- ordinary cheap
        # earbuds and off-brand trackers are frequently unnamed or use
        # manufacturer IDs outside the short common list. Give them a
        # higher benign starting count so neither can single-handedly
        # push a score over threshold before any real training exists.
        self.feature_ben["unnamed_persistent"] = 6
        self.feature_ben["manufacturer_id_unlisted"] = 8

    @classmethod
    def load(cls, path):
        m = cls()
        if not os.path.exists(path):
            return m
        try:
            with open(path) as fh:
                data = json.load(fh)
            m.malicious_total = data["malicious_total"]
            m.benign_total = data["benign_total"]
            m.feature_mal = data["feature_mal"]
            m.feature_ben = data["feature_ben"]
        except (json.JSONDecodeError, KeyError, OSError):
            return cls()  # corrupt file -> fresh informed prior, not a blind one
        return m

    def save(self, path):
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump({
                "malicious_total": self.malicious_total,
                "benign_total": self.benign_total,
                "feature_mal": self.feature_mal,
                "feature_ben": self.feature_ben,
            }, fh, indent=2)
        os.replace(tmp, path)  # atomic, no torn writes if killed mid-save

    def score(self, fired_features):
        p_mal = self.malicious_total / (self.malicious_total + self.benign_total)
        p_ben = 1.0 - p_mal

        prod_mal = p_mal
        prod_ben = p_ben

        for f in fired_features:
            p_f_mal = (self.feature_mal.get(f, 0) + 1) / (self.malicious_total + 2)
            p_f_ben = (self.feature_ben.get(f, 0) + 1) / (self.benign_total + 2)
            prod_mal *= p_f_mal
            prod_ben *= p_f_ben

        denom = prod_mal + prod_ben
        return prod_mal / denom if denom > 0 else 0.0

    def update(self, fired_features, was_malicious):
        if was_malicious:
            self.malicious_total += 1
            for f in fired_features:
                self.feature_mal[f] = self.feature_mal.get(f, 0) + 1
        else:
            self.benign_total += 1
            for f in fired_features:
                self.feature_ben[f] = self.feature_ben.get(f, 0) + 1
