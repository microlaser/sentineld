"""
Kernel process-events connector (netlink, CN_IDX_PROC) -- the same
mechanism forkstat uses, confirmed working on this machine independent of
anything we've built.

This wraps Python's built-in AF_NETLINK socket support (available since
Python 3.3, no extra dependencies) instead of hand-rolled syscall stubs
and struct definitions copied from kernel headers by hand. The wire
format is identical to the C version -- same nlmsghdr + cn_msg + payload
layout, verified byte-for-byte (40 bytes) against the C build that we
confirmed was sending correctly. If this version doesn't receive events
either, that tells us the problem was never in our message construction
at all.
"""
import os
import socket
import struct

NETLINK_CONNECTOR = 11
CN_IDX_PROC = 0x1
CN_VAL_PROC = 0x1
PROC_CN_MCAST_LISTEN = 1

PROC_EVENT_FORK = 0x00000001
PROC_EVENT_EXEC = 0x00000002
PROC_EVENT_PTRACE = 0x00000100
PROC_EVENT_EXIT = 0x80000000

NLMSG_DONE = 3

# struct nlmsghdr: __u32 len; __u16 type; __u16 flags; __u32 seq; __u32 pid;
NLMSGHDR_FMT = "=IHHII"
NLMSGHDR_SIZE = struct.calcsize(NLMSGHDR_FMT)  # 16

# struct cn_msg: struct cb_id{u32 idx,val}; u32 seq; u32 ack; u16 len; u16 flags;
CNMSG_FMT = "=IIIIHH"
CNMSG_SIZE = struct.calcsize(CNMSG_FMT)  # 20

# struct proc_event header: u32 what; u32 cpu; u64 timestamp_ns;
PROC_EVENT_HDR_FMT = "=IIQ"
PROC_EVENT_HDR_SIZE = struct.calcsize(PROC_EVENT_HDR_FMT)  # 16


class NetlinkProcConnector:
    def __init__(self, log=print):
        self.log = log
        self.sock = None

    def open(self):
        self.sock = socket.socket(socket.AF_NETLINK, socket.SOCK_DGRAM, NETLINK_CONNECTOR)
        self.log(f"sentineld: socket() fd={self.sock.fileno()}")

        pid = os.getpid()
        self.sock.bind((pid, CN_IDX_PROC))
        self.log(f"sentineld: bind() succeeded (pid={pid}, groups={CN_IDX_PROC})")

        nlmsg_len = NLMSGHDR_SIZE + CNMSG_SIZE + 4  # +4 for the int op payload
        nlh = struct.pack(NLMSGHDR_FMT, nlmsg_len, NLMSG_DONE, 0, 0, pid)
        cn = struct.pack(CNMSG_FMT, CN_IDX_PROC, CN_VAL_PROC, 0, 0, 4, 0)
        op = struct.pack("=i", PROC_CN_MCAST_LISTEN)
        msg = nlh + cn + op

        sent = self.sock.send(msg)
        self.log(f"sentineld: subscribe send() returned {sent} (message was {len(msg)} bytes)")

    def fileno(self):
        return self.sock.fileno()

    def read_events(self):
        """Reads one netlink datagram and yields (what, payload_bytes) for
        each proc_event contained in it. payload_bytes is everything after
        the proc_event header, so callers can unpack the specific union
        member for that event type."""
        buf = self.sock.recv(65536)
        self.log(f"sentineld: netlink recv() returned {len(buf)} bytes")

        offset = 0
        while offset + NLMSGHDR_SIZE <= len(buf):
            nlmsg_len, nlmsg_type, _flags, _seq, _pid = struct.unpack_from(NLMSGHDR_FMT, buf, offset)
            if nlmsg_len <= 0:
                break

            cn_offset = offset + NLMSGHDR_SIZE
            ev_offset = cn_offset + CNMSG_SIZE
            if ev_offset + PROC_EVENT_HDR_SIZE <= len(buf):
                what, _cpu, _ts = struct.unpack_from(PROC_EVENT_HDR_FMT, buf, ev_offset)
                self.log(f"sentineld: netlink event, what=0x{what:x}")
                payload = buf[ev_offset + PROC_EVENT_HDR_SIZE: offset + nlmsg_len]
                yield what, payload

            offset += nlmsg_len

    def close(self):
        if self.sock:
            self.sock.close()
