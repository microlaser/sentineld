"""
Bluetooth feature extraction: given a device's current advertised/
connected state and what's been observed about it and its neighbors
before, returns the set of anomaly signals that fired. Mirrors the
reasoning in features.py, but the "suspicious surface" here is
proximity, identity, and timing rather than exec paths -- a BLE
advertisement has no exe path or UID to check, so what's checked
instead is: does this identity match one we already trust from a
different address, is it suddenly much closer, is it cycling
connections unusually fast, and is it sticking around while refusing
to identify itself.

None of these are definitive alone -- RSSI is noisy, "no name" is also
just how a lot of ordinary earbuds behave -- which is exactly why this
feeds the same kind of Bayesian combination as the process monitor
(see bt_bayes.py) rather than a single hard rule.
"""

# A handful of extremely common Bluetooth SIG company identifiers, used
# only as a weak signal (unlisted != malicious, plenty of legitimate
# hardware uses IDs not in this short list -- see manufacturer_id_unlisted
# in bt_bayes.py's informed prior, which deliberately keeps this feature's
# weight low).
KNOWN_COMPANY_IDS = {
    0x004C: "Apple",
    0x0006: "Microsoft",
    0x00E0: "Google",
    0x0075: "Samsung",
    0x000F: "Broadcom",
    0x0087: "Garmin",
    0x0059: "Nordic Semiconductor",
    0x0157: "Anhui Huami (Amazfit)",
    0x038F: "Xiaomi",
    0x0171: "Amazon",
    0x004F: "Bluetooth SIG (test/reserved)",
}

RSSI_JUMP_THRESHOLD_DB = 25
RECONNECT_CYCLE_WINDOW_SECS = 60
RECONNECT_CYCLE_COUNT = 3
UNNAMED_PERSISTENCE_SIGHTINGS = 5
ADVERTISEMENT_BURST_WINDOW_SECS = 20
ADVERTISEMENT_BURST_COUNT = 6


def check_alias_impersonation(alias, address, trusted_devices):
    """trusted_devices: {address: alias} for paired/trusted devices.
    Fires if some OTHER trusted device's name is being broadcast by an
    address that isn't that device's -- i.e. something is presenting
    itself as a device you already trust."""
    if not alias:
        return False
    for known_addr, known_alias in trusted_devices.items():
        if known_addr == address:
            continue
        if known_alias and known_alias == alias:
            return True
    return False


def check_rssi_jump(rssi_history):
    """rssi_history: [(monotonic_time, rssi_dbm)], oldest first. Fires if
    the most recent reading is much stronger than the weakest reading
    seen recently for this device -- something that was far away and is
    now unusually close, very fast."""
    if len(rssi_history) < 2:
        return False
    recent = rssi_history[-1][1]
    baseline = min(r for _, r in rssi_history[:-1])
    return (recent - baseline) >= RSSI_JUMP_THRESHOLD_DB


def check_reconnect_cycle(connect_events):
    """connect_events: monotonic timestamps of each Connected flip
    (either direction), most recent last. Fires if several flips
    happened within the cycle window -- ordinary accessories don't
    connect/disconnect repeatedly in under a minute."""
    if len(connect_events) < RECONNECT_CYCLE_COUNT:
        return False
    window_start = connect_events[-1] - RECONNECT_CYCLE_WINDOW_SECS
    recent = [t for t in connect_events if t >= window_start]
    return len(recent) >= RECONNECT_CYCLE_COUNT


def check_unnamed_persistent(alias, sighting_count):
    return not alias and sighting_count >= UNNAMED_PERSISTENCE_SIGHTINGS


def check_uuid_drift(current_uuids, baseline_uuids):
    """baseline_uuids: the UUID set recorded the first time this address
    was confirmed paired/trusted, or None if there's no baseline (never
    paired, or paired but not yet snapshotted -- nothing to drift from
    either way)."""
    if not baseline_uuids or not current_uuids:
        return False
    return set(current_uuids) != set(baseline_uuids)


def check_manufacturer_id_unlisted(manufacturer_ids):
    if not manufacturer_ids:
        return False
    return not any(mid in KNOWN_COMPANY_IDS for mid in manufacturer_ids)


def extract_bt_features(device, trusted_devices, baseline_uuids, is_new_device):
    """device: a bluetooth.DeviceState with the current snapshot plus
    rolling history for one address.
    trusted_devices: {address: alias} snapshot of paired/trusted devices.
    baseline_uuids: previously recorded UUID set for this address, or None.
    is_new_device: True the first time this address has ever been seen
    by this daemon instance.
    """
    fired = set()

    if is_new_device and device.address not in trusted_devices:
        fired.add("new_unpaired_device")

    if check_alias_impersonation(device.alias, device.address, trusted_devices):
        fired.add("alias_mac_mismatch")

    if check_rssi_jump(device.rssi_history):
        fired.add("rssi_jump_close")

    if check_reconnect_cycle(device.connect_events):
        fired.add("rapid_connect_cycle")

    if check_unnamed_persistent(device.alias, device.sighting_count):
        fired.add("unnamed_persistent")

    if check_uuid_drift(device.uuids, baseline_uuids):
        fired.add("uuid_set_changed")

    if check_manufacturer_id_unlisted(device.manufacturer_ids):
        fired.add("manufacturer_id_unlisted")

    return fired
