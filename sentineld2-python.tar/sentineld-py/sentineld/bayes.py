"""
Naive Bayes classifier for sentineld.

Same design as the C version, but with two changes learned the hard way
during debugging that one:

1. Only features that FIRED contribute evidence (not "features that didn't
   fire" too). An earlier version multiplied in a term for every feature,
   present or absent, which meant a dozen unremarkable absent features
   reliably swamped the one or two that actually mattered.

2. The model starts with an INFORMED prior, not a blank one. These
   features were hand-picked because they're already suspicious by
   design -- a fresh install shouldn't discard that judgment and start
   mathematically incapable of ever alerting (which is what a symmetric
   zero-count prior does: Laplace smoothing makes P(feature|malicious)
   and P(feature|benign) identical when both start at zero, so the score
   is stuck at exactly 0.5 forever, regardless of what fires).

Persisted as plain JSON at /var/lib/sentineld/model.json -- readable with
`cat` or `python3 -m json.tool`, no binary format to reverse-engineer.
"""
import json
import os

FEATURES = [
    "exec_from_tmp",
    "exec_from_shm",
    "exec_from_hidden_dir",
    "deleted_binary",
    "world_writable_dir",
    "ld_preload_set",
    "unusual_parent",
    "suid_mismatch",
    "self_deleting",       # reserved: not currently populated by any feature check
    "name_spoof",
    "memfd_exec",
    "ptrace_injection",
]

EXPLANATIONS = {
    "exec_from_tmp": "It's running from /tmp or /var/tmp, folders meant for temporary files, not programs.",
    "exec_from_shm": "It's running from /dev/shm, RAM-backed storage that never touches disk.",
    "exec_from_hidden_dir": "It's running from a hidden folder (name starts with a dot).",
    "deleted_binary": "Its program file has already been deleted from disk while still running.",
    "world_writable_dir": "It's sitting in a folder anyone on this system can write to.",
    "ld_preload_set": "It's forcing other programs to load an extra library of its choosing.",
    "unusual_parent": "It was started by a program that doesn't normally launch things like this.",
    "suid_mismatch": "It runs with elevated privileges but isn't owned by root.",
    "self_deleting": "It deleted its own program file right after starting.",
    "name_spoof": "Its name imitates a system program, but it's not running from a system location.",
    "memfd_exec": "It's running entirely from memory, with no file on disk at all.",
    "ptrace_injection": "Another program just attached a debugger-style hook to a process that was already running.",
}


class BayesModel:
    def __init__(self):
        self.malicious_total = 4
        self.benign_total = 20
        self.feature_mal = {f: 3 for f in FEATURES}
        self.feature_ben = {f: 0 for f in FEATURES}

    @classmethod
    def load(cls, path):
        m = cls()
        if not os.path.exists(path):
            return m
        try:
            with open(path) as fh:
                data = json.load(fh)
            m.malicious_total = data["malicious_total"]
            m.benign_total = data["benign_total"]
            m.feature_mal = data["feature_mal"]
            m.feature_ben = data["feature_ben"]
        except (json.JSONDecodeError, KeyError, OSError):
            return cls()  # corrupt file -> fresh informed prior, not a blind one
        return m

    def save(self, path):
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump({
                "malicious_total": self.malicious_total,
                "benign_total": self.benign_total,
                "feature_mal": self.feature_mal,
                "feature_ben": self.feature_ben,
            }, fh, indent=2)
        os.replace(tmp, path)  # atomic, no torn writes if killed mid-save

    def score(self, fired_features):
        """fired_features: set/list of feature name strings that fired."""
        p_mal = self.malicious_total / (self.malicious_total + self.benign_total)
        p_ben = 1.0 - p_mal

        prod_mal = p_mal
        prod_ben = p_ben

        for f in fired_features:
            p_f_mal = (self.feature_mal.get(f, 0) + 1) / (self.malicious_total + 2)
            p_f_ben = (self.feature_ben.get(f, 0) + 1) / (self.benign_total + 2)
            prod_mal *= p_f_mal
            prod_ben *= p_f_ben

        denom = prod_mal + prod_ben
        return prod_mal / denom if denom > 0 else 0.0

    def update(self, fired_features, was_malicious):
        if was_malicious:
            self.malicious_total += 1
            for f in fired_features:
                self.feature_mal[f] = self.feature_mal.get(f, 0) + 1
        else:
            self.benign_total += 1
            for f in fired_features:
                self.feature_ben[f] = self.feature_ben.get(f, 0) + 1
