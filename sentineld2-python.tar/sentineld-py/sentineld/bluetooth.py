"""
Bluetooth anomaly connector: watches BlueZ's live device stream for RF
proximity, identity, and timing anomalies (spoofed/cloned known devices,
sudden proximity jumps, connect/disconnect cycling, persistent unnamed
beacons, advertisement bursts) -- the BLE analogue of what netlink.py
does for process exec events.

UNLIKE netlink.py, this has NOT been validated against real hardware in
this session -- there was no Bluetooth adapter available to test
against. The parsing below is based on documented `bluetoothctl` output
format and common usage patterns, not a confirmed byte-for-byte trace
the way the netlink wire format was. Treat this as a solid starting
implementation that needs a real adapter, and ideally a second device to
deliberately spoof, to shake out before you trust it the way the process
side has earned trust. Say so in README, not just here.

Design choice: this shells out to `bluetoothctl` in non-interactive
scan mode and reads its event-stream stdout, rather than talking to
BlueZ over D-Bus directly. dbus-python/pydbus would give structured
data without regex-parsing CLI text, but they're an extra dependency
this project doesn't otherwise have (everything else here is stdlib).
`bluetoothctl` ships with bluez itself -- if bluez is installed at all
(a precondition for having Bluetooth working, so this is not a real
extra dependency), this works with nothing extra to install. The
tradeoff is the same one described in the top-level README for
Python-vs-C: less structured, more readable, more likely to break if
bluetoothctl's output format changes between bluez versions. If that
turns out to matter, replacing this file's parsing with dbus-python's
GetManagedObjects + PropertiesChanged is the natural next step -- the
DeviceState/feature-extraction layer underneath doesn't need to change.
"""
import os
import re
import subprocess
import time

from .bt_features import (
    extract_bt_features,
    ADVERTISEMENT_BURST_WINDOW_SECS,
    ADVERTISEMENT_BURST_COUNT,
)

DEVICE_LINE_RE = re.compile(r"^\[(NEW|CHG|DEL)\]\s+Device\s+([0-9A-Fa-f:]{17})\s*(.*)$")
UUID_LINE_RE = re.compile(r"^([0-9a-fA-F-]{36})\b")
PAIRED_LINE_RE = re.compile(r"^Device\s+([0-9A-Fa-f:]{17})\s+(.*)$")
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")

RSSI_HISTORY_LEN = 8
CONNECT_EVENT_HISTORY_LEN = 10
BASELINE_REFRESH_SECS = 30


def strip_ansi(line):
    return ANSI_RE.sub("", line)


class DeviceState:
    def __init__(self, address):
        self.address = address
        self.alias = None
        self.connected = False
        self.uuids = set()
        self.manufacturer_ids = set()
        self.rssi_history = []      # [(monotonic_time, rssi_dbm)]
        self.connect_events = []    # [monotonic_time], one per Connected flip
        self.sighting_count = 0
        self.first_seen = time.monotonic()
        self.last_seen = self.first_seen

    def touch(self):
        self.sighting_count += 1
        self.last_seen = time.monotonic()

    def note_rssi(self, rssi):
        self.rssi_history.append((time.monotonic(), rssi))
        if len(self.rssi_history) > RSSI_HISTORY_LEN:
            self.rssi_history.pop(0)

    def note_connected_flip(self):
        self.connect_events.append(time.monotonic())
        if len(self.connect_events) > CONNECT_EVENT_HISTORY_LEN:
            self.connect_events.pop(0)


class BluetoothMonitor:
    """Owns a long-running `bluetoothctl` subprocess in scan mode and
    tracks per-address device state. Call open() once, then integrate
    fileno()/read_events() into a selector loop the same way netlink.py's
    connector is integrated: when the subprocess's stdout is readable,
    call read_events(), which yields one (DeviceState, fired_features)
    pair per line that produced a scoreable update."""

    def __init__(self, log=print):
        self.log = log
        self.proc = None
        self.devices = {}          # address -> DeviceState
        self.trusted = {}          # address -> alias, refreshed periodically
        self.baseline_uuids = {}   # address -> set(uuid), recorded once per trusted device
        self._new_addr_window = []  # monotonic timestamps of first-ever sightings
        self._last_baseline_refresh = 0.0
        self._partial_line = b""

    def open(self):
        self.proc = subprocess.Popen(
            ["bluetoothctl"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            bufsize=0,
        )
        os.set_blocking(self.proc.stdout.fileno(), False)
        self._send("scan on")
        self.log("bluetooth: bluetoothctl scan started")
        self._refresh_trusted_baseline()

    def _send(self, command):
        try:
            self.proc.stdin.write((command + "\n").encode("utf-8"))
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError) as e:
            self.log(f"bluetooth: could not send '{command}' to bluetoothctl: {e}")

    def fileno(self):
        return self.proc.stdout.fileno()

    def _refresh_trusted_baseline(self):
        """Snapshots paired/trusted devices and their UUID sets via
        `bluetoothctl devices Paired` + `info`. This is the baseline that
        alias_mac_mismatch and uuid_set_changed compare against. Runs at
        startup and periodically -- not on every event, since it shells
        out several times and paired-device membership changes rarely."""
        self._last_baseline_refresh = time.monotonic()
        try:
            result = subprocess.run(
                ["bluetoothctl", "devices", "Paired"],
                capture_output=True, text=True, timeout=5,
            )
        except (subprocess.SubprocessError, OSError) as e:
            self.log(f"bluetooth: could not list paired devices: {e}")
            return

        new_trusted = {}
        for line in result.stdout.splitlines():
            m = PAIRED_LINE_RE.match(line.strip())
            if not m:
                continue
            addr, alias = m.group(1), m.group(2)
            new_trusted[addr] = alias
            if addr not in self.baseline_uuids:
                uuids = self._fetch_uuids(addr)
                if uuids:
                    self.baseline_uuids[addr] = uuids

        self.trusted = new_trusted

    def _fetch_uuids(self, address):
        try:
            result = subprocess.run(
                ["bluetoothctl", "info", address],
                capture_output=True, text=True, timeout=5,
            )
        except (subprocess.SubprocessError, OSError):
            return set()
        uuids = set()
        for line in result.stdout.splitlines():
            m = UUID_LINE_RE.match(line.strip())
            if m:
                uuids.add(m.group(1))
        return uuids

    def _get_device(self, address):
        dev = self.devices.get(address)
        is_new = dev is None
        if is_new:
            dev = DeviceState(address)
            self.devices[address] = dev
        return dev, is_new

    def _check_burst(self):
        now = time.monotonic()
        self._new_addr_window.append(now)
        window_start = now - ADVERTISEMENT_BURST_WINDOW_SECS
        self._new_addr_window = [t for t in self._new_addr_window if t >= window_start]
        return len(self._new_addr_window) >= ADVERTISEMENT_BURST_COUNT

    def _apply_line(self, kind, address, rest):
        dev, is_new = self._get_device(address)
        dev.touch()

        burst_fired = self._check_burst() if is_new else False

        if kind == "DEL":
            return dev, is_new, burst_fired, False  # out of range -- nothing new to score

        changed = False
        if rest and ":" not in rest and not dev.alias:
            dev.alias = rest  # bare "[NEW] Device AA:BB:.. SomeName"
            changed = True
        elif rest.startswith("RSSI:"):
            try:
                dev.note_rssi(int(rest.split(":", 1)[1].strip()))
                changed = True
            except ValueError:
                pass
        elif rest.startswith("Connected:"):
            connected = rest.split(":", 1)[1].strip().lower() == "yes"
            if connected != dev.connected:
                dev.connected = connected
                dev.note_connected_flip()
                changed = True
        elif rest.startswith("Alias:") or rest.startswith("Name:"):
            dev.alias = rest.split(":", 1)[1].strip()
            changed = True
        elif rest.startswith("ManufacturerData Key:"):
            try:
                dev.manufacturer_ids.add(int(rest.split(":", 1)[1].strip(), 16))
                changed = True
            except ValueError:
                pass
        else:
            m = UUID_LINE_RE.match(rest)
            if m:
                dev.uuids.add(m.group(1))
                changed = True

        return dev, is_new, burst_fired, changed

    def read_events(self):
        """Reads whatever bluetoothctl has printed since the last call
        and yields (DeviceState, fired_features) for each device that had
        a scoreable update. Non-device lines (agent prompts, scan status
        messages) are ignored. Safe to call from a selector callback --
        the underlying pipe is non-blocking."""
        if time.monotonic() - self._last_baseline_refresh >= BASELINE_REFRESH_SECS:
            self._refresh_trusted_baseline()

        try:
            chunk = self.proc.stdout.read()
        except OSError:
            chunk = None
        if not chunk:
            return

        self._partial_line += chunk
        lines = self._partial_line.split(b"\n")
        self._partial_line = lines.pop()  # last element may be an incomplete line

        for raw in lines:
            line = strip_ansi(raw.decode("utf-8", errors="replace")).strip()
            m = DEVICE_LINE_RE.match(line)
            if not m:
                continue
            kind, address, rest = m.group(1), m.group(2), m.group(3)
            dev, is_new, burst_fired, changed = self._apply_line(kind, address, rest)
            if kind == "DEL" or not changed:
                continue

            fired = extract_bt_features(dev, self.trusted, self.baseline_uuids.get(address), is_new)
            if burst_fired:
                fired.add("advertisement_burst")
            if fired:
                yield dev, fired

    def close(self):
        if self.proc:
            try:
                self._send("scan off")
            except Exception:
                pass
            try:
                self.proc.terminate()
            except Exception:
                pass
