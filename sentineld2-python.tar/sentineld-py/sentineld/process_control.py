"""
Process control: freeze, kill-and-confirm, and a content-hash-keyed
blocklist so a blocked binary stays blocked even if copied to a new path.

hashlib.sha256 here replaces ~150 lines of hand-written, hand-verified
SHA-256 in the C version. Same security property (content identity, not
filename identity), a fraction of the code, and it's the standard
library's implementation rather than one that needed a byte-for-byte
diff against a reference to trust.
"""
import hashlib
import json
import os
import signal
import time

HASH_READ_CAP = 64 * 1024 * 1024  # matches the C version's cap


def hash_file(path):
    """Hash the file a pid's /proc/pid/exe points to. Returns hex digest
    or None if unreadable (process already exited, etc.)."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            total = 0
            while True:
                chunk = fh.read(65536)
                if not chunk:
                    break
                h.update(chunk)
                total += len(chunk)
                if total >= HASH_READ_CAP:
                    break
        return h.hexdigest()
    except OSError:
        return None


def get_process_start_time(pid):
    """jiffies-since-boot from /proc/pid/stat field 22, used to guard
    against PID-reuse races between deciding to kill and doing it."""
    try:
        with open(f"/proc/{pid}/stat") as fh:
            data = fh.read()
    except OSError:
        return None
    # comm can contain spaces/parens; split on the LAST ')' to be safe
    rest = data.rsplit(")", 1)[1].split()
    # rest[0] = state; fields continue from ppid. starttime is field 22
    # overall, i.e. index 19 in this 0-indexed rest-of-line list (rest[0]
    # is field 3/state, so field 22 is rest[19]).
    try:
        return int(rest[19])
    except (IndexError, ValueError):
        return None


def fingerprint_process(pid):
    """Returns (exe_path, sha256_hex) or (None, None) if the process is
    already gone."""
    try:
        exe_path = os.readlink(f"/proc/{pid}/exe")
    except OSError:
        return None, None
    digest = hash_file(f"/proc/{pid}/exe")
    return exe_path, digest


def stop_and_confirm(pid, timeout=2.0):
    """SIGSTOP a process and poll until the kernel confirms it's actually
    stopped (state 'T' in /proc/pid/stat), so we don't ask the user about
    something that's still free to act."""
    try:
        os.kill(pid, signal.SIGSTOP)
    except ProcessLookupError:
        return False
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with open(f"/proc/{pid}/stat") as fh:
                data = fh.read()
            state = data.rsplit(")", 1)[1].split()[0]
            if state == "T":
                return True
        except OSError:
            return False
        time.sleep(0.01)
    return False


def resume_process(pid):
    try:
        os.kill(pid, signal.SIGCONT)
        return True
    except ProcessLookupError:
        return False


def kill_and_confirm(pid, expected_start_time, timeout=5.0):
    """SIGKILL and poll /proc/<pid> until it disappears. Refuses to act if
    the process's start time doesn't match what we expected, since that
    means the PID was recycled between deciding to kill and doing it."""
    actual = get_process_start_time(pid)
    if actual is None:
        return True  # already gone
    if actual != expected_start_time:
        return False  # PID reuse race -- refuse to touch it

    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return True

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not os.path.exists(f"/proc/{pid}"):
            return True
        time.sleep(0.01)
    return False


class Blocklist:
    """Content-hash keyed list of binaries the user has chosen to block.
    Persisted as JSON; path is kept only for human-readable logging, the
    hash is the actual identity."""

    def __init__(self):
        self.entries = {}  # sha256 -> exe_path (last seen)

    @classmethod
    def load(cls, path):
        bl = cls()
        if not os.path.exists(path):
            return bl
        try:
            with open(path) as fh:
                bl.entries = json.load(fh)
        except (json.JSONDecodeError, OSError):
            return cls()
        return bl

    def save(self, path):
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(self.entries, fh, indent=2)
        os.replace(tmp, path)

    def contains(self, digest):
        return digest is not None and digest in self.entries

    def add(self, digest, exe_path):
        if digest is not None:
            self.entries[digest] = exe_path
