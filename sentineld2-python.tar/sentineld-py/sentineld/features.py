"""
Feature extraction: reads /proc for a given pid and returns the set of
suspicion signals that fired. Same feature list and reasoning as the C
version (see bayes.py:FEATURES), but using Python's stdlib for the actual
/proc parsing instead of hand-rolled string routines -- the exact category
of "did I get the parsing subtly wrong" bugs that ate a lot of the C
version's debugging time goes away when you can just do
`open(path).read()` and `str.split()`.
"""
import os

RISKY_CHILDREN = {"sh", "bash", "dash", "zsh", "python", "python3", "perl"}
DOC_PARENTS = {"soffice.bin", "acroread", "libreoffice", "evince"}
SYSTEM_NAMES = {"sshd", "systemd", "cron", "init", "kworker"}
SYSTEM_DIRS = ("/usr/", "/sbin/", "/bin/", "/lib/")


def read_proc_file(pid, leaf):
    try:
        with open(f"/proc/{pid}/{leaf}", "rb") as fh:
            return fh.read()
    except OSError:
        return b""


def resolve_exe_path(pid):
    try:
        return os.readlink(f"/proc/{pid}/exe")
    except OSError:
        return None


def parse_status(pid):
    """Returns (comm, ppid) from /proc/pid/status, or (None, None) if unreadable."""
    data = read_proc_file(pid, "status").decode("utf-8", errors="replace")
    comm, ppid = None, None
    for line in data.splitlines():
        if line.startswith("Name:"):
            comm = line.split(":", 1)[1].strip()
        elif line.startswith("PPid:"):
            ppid = int(line.split(":", 1)[1].strip())
    return comm, ppid


def is_world_writable_dir(path):
    directory = os.path.dirname(path)
    if not directory:
        return False
    try:
        mode = os.stat(directory).st_mode
    except OSError:
        return False
    return bool(mode & 0o002)


def has_setuid_owner_mismatch(exe_path):
    try:
        st = os.stat(exe_path)
    except OSError:
        return False
    return bool(st.st_mode & 0o4000) and st.st_uid != 0


def extract_features(pid, exe_path, comm, ppid, parent_comm):
    fired = set()

    if "/tmp/" in exe_path or "/var/tmp/" in exe_path:
        fired.add("exec_from_tmp")
    if "/dev/shm/" in exe_path:
        fired.add("exec_from_shm")
    if "/." in exe_path:
        fired.add("exec_from_hidden_dir")
    if "(deleted)" in exe_path:
        fired.add("deleted_binary")
    if "memfd:" in exe_path:
        fired.add("memfd_exec")
    if is_world_writable_dir(exe_path):
        fired.add("world_writable_dir")
    if has_setuid_owner_mismatch(exe_path):
        fired.add("suid_mismatch")

    environ = read_proc_file(pid, "environ")
    if b"LD_PRELOAD=" in environ:
        fired.add("ld_preload_set")

    if parent_comm in DOC_PARENTS and comm in RISKY_CHILDREN:
        fired.add("unusual_parent")

    if comm in SYSTEM_NAMES and not any(d in exe_path for d in SYSTEM_DIRS):
        fired.add("name_spoof")

    return fired
