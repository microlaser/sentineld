#!/usr/bin/env python3
"""
Standalone diagnostic: does the kernel process-events connector actually
deliver events to us? No daemon, no systemd, no capabilities config, no
Bayes model, nothing else -- just open the socket, subscribe, and print
every single thing that arrives. Run directly as root:

    sudo python3 diag_netlink.py

Then in another terminal, run something like:

    cp /bin/true /tmp/difftest && /tmp/difftest

You should see output here within milliseconds. If you see nothing at
all, the problem is upstream of anything we've written -- some kernel
config or environment quirk independent of C vs Python, and worth
comparing directly against what `forkstat` sees at the same moment.
"""
import os
import socket
import struct
import sys

NETLINK_CONNECTOR = 11
CN_IDX_PROC = 0x1
CN_VAL_PROC = 0x1
PROC_CN_MCAST_LISTEN = 1
NLMSG_DONE = 3

NLMSGHDR_FMT = "=IHHII"
CNMSG_FMT = "=IIIIHH"
PROC_EVENT_HDR_FMT = "=IIQ"

if os.geteuid() != 0:
    print("must run as root (needs CAP_NET_ADMIN)", file=sys.stderr)
    sys.exit(1)

sock = socket.socket(socket.AF_NETLINK, socket.SOCK_DGRAM, NETLINK_CONNECTOR)
print(f"socket() ok, fd={sock.fileno()}")

pid = os.getpid()
sock.bind((pid, CN_IDX_PROC))
print(f"bind() ok, pid={pid}, groups={CN_IDX_PROC}")

nlh_size = struct.calcsize(NLMSGHDR_FMT)
cn_size = struct.calcsize(CNMSG_FMT)
nlmsg_len = nlh_size + cn_size + 4

nlh = struct.pack(NLMSGHDR_FMT, nlmsg_len, NLMSG_DONE, 0, 0, pid)
cn = struct.pack(CNMSG_FMT, CN_IDX_PROC, CN_VAL_PROC, 0, 0, 4, 0)
op = struct.pack("=i", PROC_CN_MCAST_LISTEN)
msg = nlh + cn + op

sent = sock.send(msg)
print(f"subscribe send() returned {sent}, message was {len(msg)} bytes")
print()
print("Listening. Trigger a process in another terminal now.")
print("Press Ctrl-C to stop.")
print()

ev_hdr_size = struct.calcsize(PROC_EVENT_HDR_FMT)

try:
    while True:
        buf = sock.recv(65536)
        print(f"[recv] {len(buf)} bytes")
        offset = 0
        while offset + nlh_size <= len(buf):
            mlen, mtype, flags, seq, mpid = struct.unpack_from(NLMSGHDR_FMT, buf, offset)
            if mlen <= 0:
                break
            ev_offset = offset + nlh_size + cn_size
            if ev_offset + ev_hdr_size <= len(buf):
                what, cpu, ts = struct.unpack_from(PROC_EVENT_HDR_FMT, buf, ev_offset)
                print(f"  event what=0x{what:08x} cpu={cpu}")
                if what == 0x2:  # PROC_EVENT_EXEC
                    pid_off = ev_offset + ev_hdr_size
                    if pid_off + 8 <= len(buf):
                        proc_pid, proc_tgid = struct.unpack_from("=II", buf, pid_off)
                        print(f"    EXEC pid={proc_pid} tgid={proc_tgid}")
            offset += mlen
except KeyboardInterrupt:
    print("\nstopped")
