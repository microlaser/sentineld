#!/usr/bin/env python3
"""
sentinelctl - interactive companion to sentineld.

Runs unprivileged as your normal user. Can only ask the daemon to act by
sending a small JSON decision over the Unix socket -- it cannot kill
anything itself.
"""
import json
import socket
import sys

SOCK_PATH = "/run/sentineld.sock"


def print_alert(alert):
    print()
    print("=" * 57)
    print(" sentineld: a new process needs your decision")
    print("=" * 57)
    print(f" Program : {alert['comm']}")
    print(f" Path    : {alert['exe_path']}")
    print(f" PID     : {alert['pid']}  (parent: {alert.get('parent_comm', '?')}, "
          f"pid {alert.get('ppid', '?')})")
    print(f" Confidence this is malicious: {alert['score']*100:.0f}%")
    if alert.get("context_note"):
        print(f"\n Note: {alert['context_note']}")
    print("\n Why it's flagged:")
    if alert["explanations"]:
        for exp in alert["explanations"]:
            print(f"   - {exp}")
    else:
        print("   - (borderline score from combined weak signals)")
    print("\n The process is paused right now -- it is not running while you decide.")
    print("\n [b]lock and kill it   [a]llow it to continue   [f]alse positive (learn as safe)")
    print(" > ", end="", flush=True)


def print_bt_alert(alert):
    print()
    print("=" * 57)
    print(" sentineld: a Bluetooth anomaly needs your decision")
    print("=" * 57)
    print(f" Device  : {alert.get('alias') or '(no name broadcast)'}")
    print(f" Address : {alert['address']}")
    print(f" State   : {'connected' if alert.get('connected') else 'not connected'}"
          + (f", RSSI {alert['rssi']} dBm" if alert.get("rssi") is not None else ""))
    print(f" Confidence this is anomalous: {alert['score']*100:.0f}%")
    print("\n Why it's flagged:")
    if alert["explanations"]:
        for exp in alert["explanations"]:
            print(f"   - {exp}")
    else:
        print("   - (borderline score from combined weak signals)")
    print("\n Nothing has been blocked -- sentineld can't act on a Bluetooth")
    print(" device the way it can a process. This is informational.")
    print("\n [f]lag as suspicious (keep watching it)   [t]rust it (learn as safe)"
          "   [d]ismiss (no learning)")
    print(" > ", end="", flush=True)


def main():
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect(SOCK_PATH)
    except OSError as e:
        print(f"connect (is sentineld running?): {e}", file=sys.stderr)
        sys.exit(1)

    print("sentinelctl: connected. Waiting for alerts (Ctrl-C to quit)...")

    buf = b""
    try:
        while True:
            data = sock.recv(4096)
            if not data:
                print("sentineld disconnected.")
                break
            buf += data
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                if not line.strip():
                    continue
                alert = json.loads(line)

                if alert.get("type") == "bt_alert":
                    print_bt_alert(alert)
                    choice = input().strip().lower()
                    if choice.startswith("f"):
                        kind = "flag"
                        print(f"-> Flagged {alert['address']} as suspicious. Sentineld will keep watching it.")
                    elif choice.startswith("t"):
                        kind = "trust"
                        print(f"-> Marked {alert['address']} as trusted. Teaching the model this pattern is OK.")
                    else:
                        kind = "dismiss"
                        print(f"-> Dismissed the alert for {alert['address']} (no learning).")
                    decision = json.dumps({
                        "type": "bt_decision",
                        "alert_id": alert["alert_id"],
                        "kind": kind,
                    }) + "\n"
                    sock.sendall(decision.encode("utf-8"))
                    continue

                print_alert(alert)

                choice = input().strip().lower()
                if choice.startswith("b"):
                    kind = "block"
                    print(f"-> Blocking and killing PID {alert['pid']}. This binary will stay blocked.")
                elif choice.startswith("f"):
                    kind = "false_positive"
                    print(f"-> Marked safe. Resuming PID {alert['pid']} and teaching the model this pattern is OK.")
                else:
                    kind = "allow"
                    print(f"-> Allowing PID {alert['pid']} to continue this time.")

                decision = json.dumps({"alert_id": alert["alert_id"], "kind": kind}) + "\n"
                sock.sendall(decision.encode("utf-8"))
    except KeyboardInterrupt:
        print()
    finally:
        sock.close()


if __name__ == "__main__":
    main()
